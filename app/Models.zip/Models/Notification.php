<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;
    
    protected $casts = [
        'dataPayload' => 'array', // auto json_encode on save, json_decode on fetch
    ];
    
    public function user()
    {
        return $this->belongsTo('App\Models\User')->withTrashed();
    }
    
    public function from_user()
    {
        return $this->belongsTo('App\Models\User','from_id')->withTrashed();
    }
}
