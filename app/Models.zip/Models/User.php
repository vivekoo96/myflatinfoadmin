<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Collection;
use \Str;

use \DB;

class User extends Authenticatable
   
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $hidden = [
        'password', 'remember_token','api_token','otp',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    
    public function sent_notifications()
    {
        return $this->hasMany('App\Models\Notification','from_id');
    }
    
    public function getNameAttribute()
    {
        return "{$this->first_name} {$this->last_name}";
    }
    
    public function getPhotoAttribute($value)
    {
        if($value != ''){
            // return Cache::remember("signed_url_{$value}", now()->addMinutes(10), function () use ($value) {
            //     return Storage::disk('s3')->temporaryUrl($value, now()->addMinutes(10)); // Expires in 10 min
            // });
            $file_path = public_path('images/' . $this->photo_filename);
            if (is_file($file_path)) {
                    return asset('public/images/'.$value);
            }else{
                return 'https://dev.superadmin.myflatinfo.com/public/images/'.$value;
            }
        }else{
            if($this->gender == 'Female'){
                return asset('public/images/profiles/female.jpeg');
            }else{
                return asset('public/images/profiles/male.png');
            }
        }
    }
    
    public function buildings()
    {
        // Handle both old relationship (owned buildings) and new array format (assigned buildings)
        $owned = $this->hasMany('App\Models\Building')->get();
        
        // Get buildings from building_id array
        $buildingIds = $this->building_id ?: [];
        $assigned = \App\Models\Building::whereIn('id', $buildingIds)->get();
        
        // Merge and remove duplicates
        return $owned->merge($assigned)->unique('id')->values();
    }
    
    public function allBuildings()
    {
        // Buildings created/owned by user
        $owned = $this->hasMany('App\Models\Building')->get();
    
        // Buildings from building_users relationship
        $assigned = $this->departments()
            ->with('building') // assuming BuildingUser has `building()` relationship
            ->get()
            ->pluck('building')
            ->filter(); // remove nulls if any
    
        // Merge both collections and remove duplicates (by ID)
        return $owned->merge($assigned)->unique('id')->values();
    }

    public function vehicles()
    {
        return $this->hasMany('App\Models\Vehicle');
    }
    
    public function departments()
    {
        return $this->hasMany('App\Models\BuildingUser')->with('role');
    }
    
    public function hasRole($slug)
    {
        return $this->departments->contains(function ($department) use ($slug) {
            return $department->role && $department->role->slug === $slug;
        });
    }
    
    public function hasAnyRole()
    {
        return $this->departments->contains(function ($department) {
            return $department->role !== null;
        });
    }
    
    public function hasAnyCustomRole()
    {
        return $this->departments->contains(function ($department) {
            return $department->role->type == 'custom';
        });
    }
    
    public function hasAnyIssueRole()
    {
        return $this->departments->contains(function ($department) {
            return $department->role->type == 'issue';
        });
    }
    
    public function hasPermission($slug)
    {
        return \DB::table('permissions')
        ->join('role_permissions', 'permissions.id', '=', 'role_permissions.permission_id')
        ->join('building_users', 'role_permissions.role_id', '=', 'building_users.role_id')
        ->where('permissions.slug', $slug)
        ->where('building_users.user_id', $this->id)
        ->exists();
    }

    public function parcels()
    {
        return $this->hasMany('App\Models\Parcel')->withTrashed();
    }

    public function visitors()
    {
        return $this->hasMany('App\Models\Visitor')->withTrashed();
    }
    
    public function department()
    {
        return $this->belongsTo('App\Models\BuildingUser')->withTrashed();
    }
    
    public function building()
    {
        return $this->belongsTo('App\Models\Building');
    }
    
    
    public function flat()
    {
        return $this->belongsTo('App\Models\Flat');
    }
    
    
    public function city()
    {
        return $this->belongsTo('App\Models\City');
    }
    
    public function gate()
    {
        return $this->belongsTo('App\Models\Gate');
    }
    
    public function getPhotoFilenameAttribute()
    {
        return $this->attributes['photo'];
    }
    
    private function generateUniqueString($length = 8)
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
    public function getEmailAttribute($value)
    {
        return strtolower($value);
    }

     public function bookings()
    {
        return $this->hasMany('App\Models\Booking');
    }

    public function getAssignedBlocksModels()
    {
        $blockIds = $this->getAssignedBlocksArray();
        
        if (empty($blockIds)) {
            return collect();
        }
        
        return \App\Models\Block::whereIn('id', $blockIds)
                               ->where('status', 'Active')
                               ->get();
    }

    public function getAssignedBlocksArray()
    {
        if (!$this->attributes['assigned_blocks']) {
            return [];
        }
        
        $value = $this->attributes['assigned_blocks'];
        
        // If it's already an array, return it
        if (is_array($value)) {
            return $value;
        }
        
        // If it's a JSON string, decode it
        return json_decode($value, true) ?: [];
    }

    public function getAssignedBlocksAttribute($value)
    {
        if (!$value) {
            return [];
        }
        
        // If it's already an array, return it
        if (is_array($value)) {
            return $value;
        }
        
        // If it's a JSON string, decode it
        return json_decode($value, true) ?: [];
    }

    public function setAssignedBlocksAttribute($value)
    {
        $this->attributes['assigned_blocks'] = is_array($value) ? json_encode($value) : $value;
    }


}
