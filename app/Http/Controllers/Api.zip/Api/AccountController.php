<?php

namespace App\Http\Controllers\Api;
use App\Jobs\SendForgetPasswordEmail;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Setting;
use App\Models\User;
use App\Models\Building;
use App\Models\Flat;
use App\Models\Noticeboard;
use App\Models\Event;
use App\Models\Classified;
use App\Models\Role;
use App\Models\Issue;
use App\Models\IssuePhoto;
use App\Models\Comment;
use App\Models\Reply;
use App\Models\Facility;
use App\Models\Timing;
use App\Models\Booking;
use App\Models\Visitor;
use App\Models\VisitorInout;
use App\Models\FamilyMember;
use App\Models\Guard;
use App\Models\Vehicle;
use App\Models\VehicleInout;
use App\Models\GatePass;
use App\Models\ClassifiedPhoto;
use App\Models\BuildingUser;
use App\Models\Gate;
use App\Models\Ad;
use App\Models\Parcel;
use App\Models\MaintenancePayment;
use App\Models\EssentialPayment;
use App\Models\Payment;
use App\Models\Order;
use App\Models\Transaction;
use App\Models\Essential;
use App\Models\BuildingPermission;
use App\Models\Expense;
use App\Models\Maintenance;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;
use Illuminate\Validation\Rule;

use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;
use Kreait\Firebase\Exception\MessagingException;
use Barryvdh\DomPDF\Facade\Pdf;
use DB;
use \Session;
use Mail;
use \Str;
use \Log;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Razorpay\Api\Api;

use Illuminate\Support\Arr;


use \Hash;
use \Auth;

class AccountController extends Controller
{
    public function __construct()
    {
        
        $rdata = Setting::findOrFail(1);
        $this->keyId = $rdata->razorpay_key;
        $this->keySecret = $rdata->razorpay_secret;
        $this->displayCurrency = 'INR';

        $this->api = new Api($this->keyId, $this->keySecret);
    }
    
    public function get_setting()
    {
        $setting = Setting::first();
        return response()->json([
            'setting' => $setting
        ],200); 
    }
    
    public function user_status()
    {
        $user = Auth::User();
        
        return response()->json([
            'profile_status' => $user->profile_status,
            'status' => $user->status,
        ],200); 
    }
    
    public function send_otp(Request $request)
    {
        $user = User::where('email',$request->email)->first();
        if($user){
            if($user->status == 'Active'){
                return response()->json([
                    'error' => 'You are already registerd with us, Please login'
                ],422);
            }else{
                $otp = rand(1000,9999);
                $user->otp = Hash::make($otp);
                $user->save();
                //Send email with OTP
                Mail::send([], [], function ($message) use ($user, $otp) {
                    $message->to($user->email)
                        ->subject('Sign up OTP')
                        ->setBody("Your OTP for signup is: $otp", 'text/html');
                });
                return response()->json([
                    'msg' => 'OTP has been sent successfully.'
                ],200);
            }
            
            
        }else{
            $user = new User();
        }
        $rules = [
            'email' => 'required|unique:users|email',
        ];
        
        $validation = \Validator::make( $request->all(), $rules );
        $error = $validation->errors()->first();
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ], 422);
        }
        
        $user->role = 'customer';
        $otp = rand(1000,9999);
        $user->email = $request->email;
        $user->status = 'Pending';
        $user->otp = Hash::make($otp);
        $user->otp_status = 'Sent';
        $user->referal_code = 'MFIB'.rand(100000,999999);
        $user->save();
        
        //Send email with OTP
        Mail::send([], [], function ($message) use ($user, $otp) {
            $message->to($user->email)
                ->subject('Sign up OTP')
                ->setBody("Your OTP for signup in Allons-Z is: $otp", 'text/html');
        });
        
            
        return response()->json([
            'msg' => 'OTP has been sent successfully.'
        ],200);
    }
    
    public function resend_otp(Request $request)
    {
        $rules = [
            'email' => 'required|email',
        ];
        $validation = \Validator::make( $request->all(), $rules );
        $error = $validation->errors()->first();
        if($error){
            return response()->json([
                'error' => $error
            ],422);
        }
        
        $user = User::where('email',$request->email)->first();
        if(!$user){
            return response()->json([
                'error' => 'This email is not registered with us'
            ],422);
        }
        
        $otp = rand(1000,9999);
        
        $info = array(
            'user' => Auth::User(),
            'otp' => $otp
        );
        Mail::send([], [], function ($message) use ($user, $otp) {
            $message->to($user->email)
                ->subject('Sign up OTP')
                ->setBody("Your OTP for Allons-Z is: $otp", 'text/html');
        });

        $user->otp = Hash::make($otp);
        $user->otp_status = 'Sent';
        $user->save();

        return response()->json([
            'msg' => 'OTP has been sent successfully.'
        ],200);
    }
    
    public function forget_password(Request $request)
    {
        $rules = [
            'email' => 'required|email|exists:users,email',
        ];
        $validation = \Validator::make( $request->all(), $rules );
        $error = $validation->errors()->first();
        if($error){
            return response()->json([
                'error' => $error
            ],422);
        }
        
        $user = User::where('email',$request->email)->first();
        if(!$user){
            return response()->json([
                'error' => 'This email is not registered with us'
            ],422);
        }
        if($user->hasRole('accounts')){
            //
        }else{
            return response()->json([
                'error' => 'This user is not belongs to accounts'
            ],422);
        }
        $otp = rand(1000,9999);
        $setting = Setting::first();
        $logo = $setting->logo;
        $info = array(
            'user' => $user,
            'otp' => $otp,
            'logo' => $logo
        );
        try {
            // dispatch(new SendForgetPasswordEmail($user, $info));
            Mail::send('email.forget_password2', $info, function ($message) use ($user) {
                $message->to($user->email, $user->name)
                        ->subject('Forget Password');
            });
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to queue email. ' . $e->getMessage()
            ], 500);
        }

        $user->otp = Hash::make($otp);
        $user->otp_status = 'Sent';
        $user->save();

        return response()->json([
            'msg' => 'OTP has been sent successfully.'
        ],200);
    }
    
    public function verify_otp(Request $request)
    {
        
        $rules = [
            'email' => 'required|email|exists:users,email',
            'otp' => 'required|numeric|digits:4',
        ];
        $validation = \Validator::make( $request->all(), $rules );
        $error = $validation->errors()->first();
        if($error){
            return response()->json([
                'error' => $error
            ],422);
        }
        $user = User::where('email',$request->email)->first();
        if(!$user){
            return response()->json([
                'error' => 'This user is not belongs to accounts'
            ],422);
        }
        if($user->hasRole('accounts')){
            //
        }else{
            return response()->json([
                'error' => 'This user is not belongs to accounts'
            ],422);
        }
        if($user){
            if (Hash::check($request->otp, $user->otp)) {
                if($user->otp_status == 'Sent'){
                    $user->otp_status = 'Verified';
                    $token = $user->createToken('MyApp')->accessToken;
                    $user->api_token = $token;
                    $user->device_token = $request->device_token;
                    $user->save();
                    Auth::login($user, true);
                    return response()->json([
                        'token' => $token,
                        'user' => $user,
                        'msg' => 'OTP verified successfully.'
                    ],200);
                }
                return response()->json([
                        'error' => 'This OTP has already been used. Please request a new OTP'
                ],422);
                
            }else{
                return response()->json([
                        'error' => 'Invalid OTP'
                ],422);
            }
        }
        return response()->json([
                'error' => 'Invalid email or OTP.'
        ],422);
    }
    
    public function update_password(Request $request)
    {
        $rules = [
            'password' => [
                'required',
                'string',
                'max:16',
                'min:8',             // must be at least 8 characters in length
                'regex:/[a-z]/',      // must contain at least one lowercase letter
                'regex:/[A-Z]/',      // must contain at least one uppercase letter
                'regex:/[0-9]/',      // must contain at least one digit
                'regex:/[@$!%*#?&]/', // must contain a special character
                'regex:/^\S*$/',      // Must not contain spaces
                'confirmed',
            ],
        ];

        $validation = \Validator::make( $request->all(), $rules );
        $error = $validation->errors()->first();
        if($error){
            return response()->json([
                'error' => $error
            ],422);
        }
        
        $user = Auth::User();
        
        if($user){
            $user->password = Hash::make($request->password);
            $user->status = 'Active';
            $user->save();
            return response()->json([
                'msg' => 'Password updated.'
            ],200);
        }
        return response()->json([
                'error' => 'User not found.'
        ],422);
    }

    public function login(Request $request)
    {
        $rules = [
            
            'email' => 'required|email',
            'password' => [
                'required',
            ],
        ];

        $validation = \Validator::make( $request->all(), $rules );
        $error = $validation->errors()->first();
        if($error){
            return response()->json([
                'error' => $error
            ],422);
        }
        
        $user = User::where('email',$request->email)->first();
        
        if(!$user){
            return response()->json([
                'error' => 'This account is not register with us'
            ],422);
        }
        if($user->hasRole('accounts')){
            //
        }else{
            return response()->json([
                'error' => 'This user is not belongs to accounts'
            ],422);
        }
        if($user && $user->status == 'Active'){
            if (Hash::check($request->password, $user->password)) {
                $token = $user->createToken('MyApp')->accessToken;
                $user->api_token = $token;
                $user->device_token = $request->device_token;
                $user->fcm_token = $request->fcm_token;
                $user->platform = $request->platform;
                $user->save();
                Auth::login($user, true);
                return response()->json([
                    'token' => $token,
                    'user' => $user,
                    'msg' => 'Login Successfull.'
                ],200);
            }else{
                return response()->json([
                    'error' => 'Invalid Password'
                ],422);
            }
        }else{
            return response()->json([
                'error' => 'This account is Inactive'
            ],422);
        }
        return response()->json([
            'error' => 'This email is not registered with us'
        ],422);
    }

    public function profile(Request $request)
    {
        $user = Auth::User();
        $building = $user->building;
        if ($user->fcm_token) {
            $factory = (new Factory)
                ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json')); // adjust path if needed
    
            $messaging = $factory->createMessaging();
    
            $notification = Notification::create('Welcome, ' . $user->name, 'You accessed your profile!');
    
            $message = CloudMessage::withTarget('token', $user->fcm_token)
                ->withNotification($notification)
                ->withData([
                    'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                    'type' => 'profile_access',
                    'user_id' => (string)$user->id,
                ]);
    
            try {
                $messaging->send($message);
            } catch (\Kreait\Firebase\Exception\MessagingException $e) {
                return response()->json(['error' => 'FCM Error: ' . $e->getMessage()], 500);
            }
        }
        
        // send push notification
        return response()->json([
            'user' => $user,
        ],200);
    }
    
    public function update_profile(Request $request)
    {
        $user = Auth::user();

        $rules = [
            'first_name' => 'required|string|max:255|regex:/^[A-Z][a-z]*$/',
            'last_name' => 'required|string|max:255|regex:/^[A-Z][a-z]*$/',
            'phone' => 'required|unique:users,phone,' . $user->id . '|regex:/^([0-9\s\-\+\(\)]*)$/|size:10',
            'gender' => 'required|in:Male,Female,Other',
            'city_id' => 'required|exists:cities,id|numeric',
            'address' => 'required|string|min:4',
            // 'pincode' => 'required|numeric|digits:6|',
        ];
    
        $validation = \Validator::make($request->all(), $rules);
        $error = $validation->errors()->first();
        if ($error) {
            return response()->json([
                'error' => $error
            ], 422);
        }

        // if($request->hasFile('photo')) {
        //     $file= $request->file('photo');
        //     $allowedfileExtension=['jpeg','jpeg','png'];
        //     $extension = $file->getClientOriginalExtension();
        //     Storage::disk('s3')->delete($user->getPhotoFilenameAttribute());
        //     $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        //     $filename = 'images/profiles/' . uniqid() . '.' . $extension;
        //     Storage::disk('s3')->put($filename, file_get_contents($file));
        //     $user->photo = $filename;
        // }
        if ($request->hasFile('photo')) {
            $file = $request->file('photo');
            $allowedfileExtension = ['jpeg', 'jpg', 'png'];
            $extension = $file->getClientOriginalExtension();
            if (!empty($user->photo_filename)) {
                $file_path = public_path('images/' . $user->photo_filename);
            
                if (is_file($file_path)) {
                    unlink($file_path);
                }
            }

            $filename = 'profiles/' . uniqid() . '.' . $extension;
            $path = $file->move(public_path('/images/profiles/'), $filename);
            $user->photo = $filename;
        }
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone = $request->phone;
        $user->gender = $request->gender;
        $user->city_id = $request->city_id;
        $user->address = $request->address;
        // $user->pincode = $request->pincode;
        $user->save();
    
        return response()->json([
            'msg' => 'Profile updated successfully',
            'user' => $user
        ], 200);
    }
    
    public function change_password(Request $request)
    {
        $user = Auth::user();
        $rules = [
            'old_password' => 'required',
            'password' => [
                'required',
                'string',
                'max:16',
                'min:8',             // must be at least 8 characters in length
                'regex:/[a-z]/',      // must contain at least one lowercase letter
                'regex:/[A-Z]/',      // must contain at least one uppercase letter
                'regex:/[0-9]/',      // must contain at least one digit
                'regex:/[@$!%*#?&]/', // must contain a special character
                'regex:/^\S*$/',      // Must not contain spaces
                'confirmed',
            ],
            
        ];
    
        $validation = \Validator::make($request->all(), $rules);
        $error = $validation->errors()->first();
        if ($error) {
            return response()->json([
                'error' => $error
            ], 422);
        }
        if (Hash::check($request->old_password, $user->password)) {
            $user->password = Hash::make($request->password);
            $user->save();
            return response()->json([
                'msg' => 'Password updated.'
            ],200);
        }
        
        return response()->json([
                'msg' => 'Invalid old password.'
            ],200);
    }
    
    public function get_buildings(Request $request)
    {
        $user = Auth::User();
        $buildings = $user->allBuildings();
        return response()->json([
            'buildings' => $buildings
        ], 200);
    }
    public function select_building(Request $request)
    {
        $rules = [
            'building_id' => 'required|exists:buildings,id',
        ];
    
        $validation = \Validator::make($request->all(), $rules);
        $error = $validation->errors()->first();
        if ($error) {
            return response()->json([
                'error' => $error
            ], 422);
        }
        $user = Auth::User();
        $building = $user->allBuildings()->where('id',$request->building_id);
        if(!$building){
            return response()->json([
                'error' => 'This building is not belongs to this account',
            ], 422);
        }
        $user->building_id = $request->building_id;
        $user->device_token = $request->device_token;
        $user->fcm_token = $request->fcm_token;
        $user->platform = $request->platform;
        $user->save();
        

        return response()->json([
            'building' => $building,
        ], 200);
    }

    public function get_flats(Request $request)
    {
        $user = Auth::User();
        $building = Building::where('id',$user->building_id)->with(['blocks.flats'])->get();
        return response()->json([
                 'message' => 'Building data retrieved successfully',
            'building' => $building
        ], 200);
    }

    public function flat_details(Request $request)
    {
        $user = Auth::User();
        $flat = Flat::where('building_id',$user->building_id)->where('id',$request->flat_id)->with(['building','block','family_members','parcels','maintenance_payments','essential_payments'])->first();
        return response()->json([
            'flat' => $flat
        ], 200);
    }
    
    public function update_corpus_fund(Request $request)
    {
        $rules = [
            'flat_id' => 'required|exists:flats,id',
            'corpus_fund' => 'required',
            'is_corpus_paid' => 'required',
            'corpus_paid_on' => 'nullable|date',
            'payment_type' => 'required',
        ];
    
        $msg = 'Corpus fund Added';
        $flat = Flat::withTrashed()->find($request->flat_id);
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ], 422);
        }

        $flat->corpus_fund = $request->corpus_fund;
        $flat->is_corpus_paid = $request->is_corpus_paid;
        $flat->corpus_paid_on = $request->corpus_paid_on;
        $flat->corpus_payment_type = $request->payment_type;
        if($flat->bill_no == Null || $flat->bill_no == ''){
            $flat->bill_no = Str::random(16);
        }
        if($request->is_corpus_paid == 'No')
        {
            $flat->corpus_paid_on = NULL;
            $flat->bill_no = Null;
        }
        $flat->save();
        
        $transaction = Transaction::where('model','CorpusFund')->where('model_id',$flat->id)->first();
        if(!$transaction){
            $transaction = new Transaction();
        }
            $transaction->building_id = $flat->building_id;
            $transaction->user_id = $flat->owner_id;
            // $transaction->order_id = $order->order_id;
            $transaction->model = 'Corpus';
            $transaction->type = 'Credit';
            $transaction->payment_type = $request->payment_type;
            $transaction->date = $request->corpus_paid_on;
            $transaction->amount = $request->corpus_fund;
            $transaction->reciept_no = 'RCP'.rand(10000000,99999999);
            $transaction->desc = 'Corpus Fund for '.$flat->name;
            $transaction->status = 'Success';
            $transaction->save();
        
        return response()->json([
            'msg' => $msg
        ], 200);
    }
    
    public function get_opening_balance(Request $request)
    {
        $user = Auth::User();
        $building = $user->building()->select(['id','maintenance_in_bank','maintenance_in_hand','corpus_in_bank','corpus_in_hand'])->first();
        
        $can_update = 'Yes';
        $transaction = Transaction::where('building_id',$building->id)->where('model','Opening')->first();
        if($transaction){
            $can_update = 'No';
        }
        return response()->json([
            'building' => $building,
            'can_update' => $can_update
        ], 200);
    }
    
    public function update_opening_balance(Request $request)
    {
        $rules = [
            'maintenance_in_bank' => 'required|int',
            'maintenance_in_hand' => 'required|int',
            'corpus_in_bank' => 'required|int',
            'corpus_in_hand' => 'required|int',
        ];
    
        $validation = \Validator::make($request->all(), $rules);
        $error = $validation->errors()->first();
        if ($error) {
            return response()->json([
                'error' => $error
            ], 422);
        }
        
        $user = Auth::User();
        $building = $user->building;
        $transaction = Transaction::where('building_id',$building->id)->where('model','Opening')->first();
        if($transaction){
            return response()->json([
                'error' => 'Opening balance already updated'
            ], 422);
        }
        $building->maintenance_in_bank = $request->maintenance_in_bank;
        $building->maintenance_in_hand = $request->maintenance_in_hand;
        $building->corpus_in_bank = $request->corpus_in_bank;
        $building->corpus_in_hand = $request->corpus_in_hand;
        $building->save();
        
        $transaction = new Transaction();
        $transaction->building_id = $building->id;
        $transaction->user_id = $building->user_id;
        $transaction->model = 'Opening';
        $transaction->type = 'Credit';
        $transaction->payment_type = 'InBank';
        $transaction->amount = $request->maintenance_in_bank;
        $transaction->desc = 'Opening Maintenance Balance InBank';
        $transaction->reciept_no = 'RCP'.rand(10000000,99999999);
        $transaction->status = 'Success';
        $transaction->date = now()->toDateString();
        $transaction->save();
        
        $transaction = new Transaction();
        $transaction->building_id = $building->id;
        $transaction->user_id = $building->user_id;
        $transaction->model = 'Opening';
        $transaction->type = 'Credit';
        $transaction->payment_type = 'InHand';
        $transaction->amount = $request->maintenance_in_hand;
        $transaction->desc = 'Opening Maintenance Balance InHand';
        $transaction->reciept_no = 'RCP'.rand(10000000,99999999);
        $transaction->status = 'Success';
        $transaction->date = now()->toDateString();
        $transaction->save();
        
        $transaction = new Transaction();
        $transaction->building_id = $building->id;
        $transaction->user_id = $building->user_id;
        $transaction->model = 'Opening';
        $transaction->type = 'Credit';
        $transaction->payment_type = 'InBank';
        $transaction->amount = $request->corpus_in_bank;
        $transaction->desc = 'Opening Corpus Balance InBank';
        $transaction->reciept_no = 'RCP'.rand(10000000,99999999);
        $transaction->status = 'Success';
        $transaction->date = now()->toDateString();
        $transaction->save();
        
        $transaction = new Transaction();
        $transaction->building_id = $building->id;
        $transaction->user_id = $building->user_id;
        $transaction->model = 'Opening';
        $transaction->type = 'Credit';
        $transaction->payment_type = 'InHand';
        $transaction->amount = $request->corpus_in_hand;
        $transaction->desc = 'Opening Corpus Balance InHand';
        $transaction->reciept_no = 'RCP'.rand(10000000,99999999);
        $transaction->status = 'Success';
        $transaction->date = now()->toDateString();
        $transaction->save();
        
        return response()->json([
            'msg' => 'Opening blance updated successfully'
        ], 200);
    }
    
    public function get_model_data(Request $request)
    {
        $user = Auth::User();
        $model = $request->model;
        if ($model == 'Event') {
            $data = Event::select(['id', 'name'])->where('building_id',$user->building_id)->get();
        } elseif ($model == 'Essential') {
            $data = Essential::select(['id', DB::raw('reason as name')])->where('building_id',$user->building_id)->get();
        } elseif ($model == 'Facility') {
            $data = Facility::select(['id', 'name'])->where('building_id',$user->building_id)->get();
        }
        else {
            $data = collect(); // Empty collection if no model matched
        }
        return response()->json([
                'data' => $data
        ],200);
    }
    
    public function income_and_expenditure(Request $request)
    {
        $building = Auth::User()->building;
        $transactionsQuery = Transaction::where('building_id', $building->id);

        // Filter by model and model_id
        if ($request->filled('model') && $request->model != 'All') {
            $transactionsQuery->where('model', $request->model);

            if ($request->filled('model_id')) {
                $transactionsQuery->where('model_id', $request->model_id);
            }
        }

        // Filter by from_date and to_date
        if ($request->filled('from_date')) {
            $transactionsQuery->whereDate('date', '>=', $request->from_date);
        }

        if ($request->filled('to_date')) {
            $transactionsQuery->whereDate('date', '<=', $request->to_date);
        }

        $transactions = $transactionsQuery->orderBy('date','desc')->get();

        // Initialize totals
        $total_debit = 0;
        $total_credit = 0;
        $inhand = 0;
        $inbank = 0;

        foreach ($transactions as $transaction) {
            if ($transaction->type == 'Debit') {
                $total_debit += $transaction->amount;
            } elseif ($transaction->type == 'Credit') {
                $total_credit += $transaction->amount;
            }

            // Separate logic for inhand and inbank
            if ($transaction->payment_type == 'InHand') {
                $inhand += ($transaction->type == 'Credit' ? $transaction->amount : -$transaction->amount);
            } elseif ($transaction->payment_type == 'InBank') {
                $inbank += ($transaction->type == 'Credit' ? $transaction->amount : -$transaction->amount);
            }
        }
        $inhand = $inhand + $building->maintenance_in_hand + $building->corpus_in_hand;
        $inbank = $inbank + $building->maintenance_in_bank + $building->corpus_in_bank;
        $building = Auth::User()->building;
        return response()->json([
            'building' => $building,
            'transactions' => $transactions,
            'inhand' => $inhand,
            'inbank' => $inbank,
            'total_debit' => $total_debit,
            'total_credit' => $total_credit,
        ], 200);
    }
    
    public function form_payments()
    {
        $user = Auth::User();
        $building = $user->building;
        $expenses = $building->expenses()->where('type','Debit')->orderBy('date','desc')->get();
        return response()->json([
            'expenses' => $expenses
        ], 200);
    }
    
    public function form_reciepts()
    {
        $user = Auth::User();
        $building = $user->building;
        $expenses = $building->expenses()->where('type','Credit')->orderBy('date','desc')->get();
        return response()->json([
            'expenses' => $expenses
        ], 200);
    }
    
    public function form_store_payment(Request $request)
    {
        $rules = [
            'model' => 'required',
            'model_id' => 'nullable|int',
            'payment_type' => 'required|in:InHand,InBank',
            'reason' => 'required',
            'amount' => 'required',
            'date' => 'required',
            'image' => 'nullable|image'
        ];
    
        $msg = 'Expense added Susccessfully';
        $expense = new Expense();
    
        if ($request->id) {
            $expense = Expense::find($request->id);
            $msg = 'Expense updated Susccessfully';
        }
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            
            return response()->json([
                'error' => $validation->errors()->first()
            ],422);
        }
        $user = Auth::User();
        $expense->user_id = $user->id;
        $expense->building_id = $user->building_id;
        $expense->model = $request->model;
        $expense->model_id = $request->model_id;
        $expense->payment_type = $request->payment_type;
        $expense->reason = $request->reason;
        $expense->type = 'Debit';
        $expense->date = $request->date;
        $expense->amount = $request->amount;
        // if($request->hasFile('image')) {
        //     $file= $request->file('image');
        //     $allowedfileExtension=['jpeg','jpeg','png'];
        //     $extension = $file->getClientOriginalExtension();
        //     Storage::disk('s3')->delete($expense->getImageFilenameAttribute());
        //     $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        //     $filename = 'images/expenses/' . uniqid() . '.' . $extension;
        //     Storage::disk('s3')->put($filename, file_get_contents($file));
        //     $expense->image = $filename;
        // }
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $allowedfileExtension = ['jpeg', 'jpg', 'png'];
            $extension = $file->getClientOriginalExtension();
            if (!empty($expense->photo_filename)) {
                $file_path = public_path('images/' . $expense->image_filename);
            
                if (is_file($file_path)) {
                    unlink($file_path);
                }
            }

            $filename = 'expenses/' . uniqid() . '.' . $extension;
            $path = $file->move(public_path('/images/expenses/'), $filename);
            $expense->image = $filename;
        }
        
        $expense->save();
        $transaction = new Transaction();
        $transaction->building_id = $user->building_id;
        $transaction->user_id = $user->id;
        $transaction->model = $request->model;
        $transaction->model_id = $request->model_id;
        $transaction->date = $request->date;
        $transaction->type = 'Debit';
        $transaction->payment_type = $request->payment_type;
        $transaction->amount = $request->amount;
        $transaction->reciept_no = 'EXPS'.rand(10000000,99999999);
        $transaction->desc = $request->reason;
        $transaction->status = 'Success';
        $transaction->save();
        
        return response()->json([
            'msg' => $msg
        ], 200);
    }
    
    public function form_store_reciept(Request $request)
    {
        $rules = [
            'model' => 'required',
            'model_id' => 'nullable|int',
            'payment_type' => 'required|in:InHand,InBank',
            'reason' => 'required',
            'amount' => 'required',
            'date' => 'required',
            'image' => 'nullable|image'
        ];
    
        $msg = 'Reciept added Susccessfully';
        $expense = new Expense();
    
        if ($request->id) {
            $expense = Expense::find($request->id);
            $msg = 'Reciept updated Susccessfully';
        }
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            
            return response()->json([
                'error' => $validation->errors()->first()
            ],422);
        }
        $user = Auth::User();
        $expense->user_id = $user->id;
        $expense->building_id = $user->building_id;
        $expense->model = $request->model;
        $expense->model_id = $request->model_id;
        $expense->payment_type = $request->payment_type;
        $expense->reason = $request->reason;
        $expense->type = 'Credit';
        $expense->date = $request->date;
        $expense->amount = $request->amount;
        // if($request->hasFile('image')) {
        //     $file= $request->file('image');
        //     $allowedfileExtension=['jpeg','jpeg','png'];
        //     $extension = $file->getClientOriginalExtension();
        //     Storage::disk('s3')->delete($expense->getImageFilenameAttribute());
        //     $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        //     $filename = 'images/expenses/' . uniqid() . '.' . $extension;
        //     Storage::disk('s3')->put($filename, file_get_contents($file));
        //     $expense->image = $filename;
        // }
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $allowedfileExtension = ['jpeg', 'jpg', 'png'];
            $extension = $file->getClientOriginalExtension();
            if (!empty($expense->photo_filename)) {
                $file_path = public_path('images/' . $expense->image_filename);
            
                if (is_file($file_path)) {
                    unlink($file_path);
                }
            }

            $filename = 'expenses/' . uniqid() . '.' . $extension;
            $path = $file->move(public_path('/images/expenses/'), $filename);
            $expense->image = $filename;
        }
        $expense->save();
        $transaction = new Transaction();
        $transaction->building_id = $user->building_id;
        $transaction->user_id = $user->id;
        $transaction->model = $request->model;
        $transaction->model_id = $request->model_id;
        $transaction->date = $request->date;
        $transaction->type = 'Credit';
        $transaction->payment_type = $request->payment_type;
        $transaction->amount = $request->amount;
        $transaction->reciept_no = 'RCPT'.rand(10000000,99999999);
        $transaction->desc = $request->reason;
        $transaction->status = 'Success';
        $transaction->save();
        
        return response()->json([
            'msg' => $msg
        ], 200);
    }
    
    public function generate_maintenance(Request $request)
    {
        $building = Auth::User()->building;
        $maintenances = $building->maintenances;
        return response()->json([
            'maintenances' => $maintenances,
        ], 200);
    }
    
    public function add_new_maintenance(Request $request)
    {
        $rules = [
            'maintenance_id' => 'nullable|exists:maintenances,id',
            'from_date' => 'required',
            'to_date' => 'required',
            'amount' => 'required',
            'vacant_amount' => 'required',
            'maintenance_type' => 'required|in:Areawise,Custom',
            'due_date' => 'required',
            'late_fine_type' => 'required|in:Percentage,Daily,Fixed',
            'late_fine_value' => 'required',
            'gst' => 'required',
            'status' => 'required|in:Active,Inactive',
        ];
    
        $msg = 'Maintenance added Susccessfully';
        $maintenance = new Maintenance();
        if($request->maintenance_id) {
            $maintenance = Maintenance::withTrashed()->find($request->maintenance_id);
            $msg = 'Maintenance udated Susccessfully';
        }
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ],422);
        }
        $user = Auth::User();
        $maintenance->user_id = $user->id;
        $maintenance->building_id = $user->building_id;
        $maintenance->from_date = $request->from_date;
        $maintenance->to_date = $request->to_date;
        $maintenance->amount = $request->amount;
        $maintenance->vacant_amount = $request->vacant_amount;
        $maintenance->maintenance_type = $request->maintenance_type;
        $maintenance->due_date = $request->due_date;
        $maintenance->late_fine_type = $request->late_fine_type;
        $maintenance->late_fine_value = $request->late_fine_value;
        $maintenance->gst = $request->gst;
        $maintenance->status = $request->status;
        $maintenance->save();
        
        foreach($user->building->flats as $flat)
        {
            if($flat->sold_out == 'Yes'){
                if($request->maintenance_id) {
                    $maintenance_payment = MaintenancePayment::where('flat_id',$flat->id)
                        ->where('maintenance_id',$maintenance->id)
                        ->first();
        
                    // If not found, skip this flat
                    if (!$maintenance_payment) {
                        continue;
                    }
                }
        
                // If maintenance_id was not passed, create new payment
                if (!$request->maintenance_id) {
                    $maintenance_payment = new MaintenancePayment();
                }
                $maintenance_payment->maintenance_id = $maintenance->id;
                $maintenance_payment->building_id = $maintenance->building_id;
                $maintenance_payment->flat_id = $flat->id;
                $maintenance_payment->user_id = $flat->tanent ? $flat->tanent_id : $flat->owner_id;
                $maintenance_payment->living_status = $flat->living_status;
                $maintenance_payment->paid_amount = 0;
                $maintenance_payment->dues_amount = $maintenance->amount;
                $maintenance_payment->bill_no = 'MFIB'.rand(100000,999999);
                if($maintenance->maintenance_type == 'Areawise'){
                    if($flat->living_status == 'Vacant'){
                        $maintenance_payment->dues_amount = $flat->area * $request->vacant_amount;
                    }else{
                        $maintenance_payment->dues_amount = $flat->area * $request->amount;
                    }
                }else{
                    if($flat->living_status == 'Vacant'){
                        $maintenance_payment->dues_amount = $request->vacant_amount;
                    }else{
                        $maintenance_payment->dues_amount = $request->amount;
                    }
                }
                $maintenance_payment->late_fine = 0;
                $maintenance_payment->type = 'Created';
                $maintenance_payment->status = 'Unpaid';
                $maintenance_payment->save();
                
                // Check if user has a device token
                $tanent = $flat->tanent;
                $owner = $flat->owner;
                
                $usersToNotify = collect([$tanent, $owner])->filter();

                foreach ($usersToNotify as $targetUser) {
                    if ($targetUser && $targetUser->fcm_token) {
                        $factory = (new Factory)
                            ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json'));
                
                        $messaging = $factory->createMessaging();
                
                        $notification = Notification::create(
                            'New Maintenance Payment Added',
                            'A new maintenance payment has been added by the BA. Please check the details and complete the payment.'
                        );
                
                        $dataPayload = [
                            'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                            'screen' => 'MaintenancePage',
                            'params' => json_encode(['maintenanceId' => $maintenance->id]),
                            'categoryId' => '',
                            'channelId' => '',
                            'sound' => 'bellnotificationsound.wav',
                            'type' => 'MAINTENANCE_ADDED',
                            'user_id' => (string)$targetUser->id,
                        ];
                
                        $message = CloudMessage::withTarget('token', $targetUser->fcm_token)
                            ->withNotification($notification)
                            ->withData($dataPayload);
                
                        try {
                            $messaging->send($message);
                        } catch (MessagingException $e) {
                            \Log::error("FCM Error for user {$targetUser->id}: " . $e->getMessage());
                            // Optionally continue notifying others instead of returning early
                        }
                    }
                }
        
                
            }
            
        }
        return response()->json([
            'msg' => $msg,
        ], 200);
    
    }
    
    public function manage_maintenance(Request $request)
    {
        $user = Auth::user();
        $building = $user->building;
        $blocks = $building->blocks()->with(['flats'])->get();
        $flat_id = $request->flat_id;
    
        $query = MaintenancePayment::where('building_id', $building->id)
            ->whereIn('id', function ($subquery) use ($building) {
                $subquery->selectRaw('MAX(id)')
                    ->from('maintenance_payments')
                    ->where('building_id', $building->id)
                    ->groupBy('flat_id');
            });
    
        // Optional filter by flat_id
        if ($request->filled('flat_id') && $request->flat_id > 0) {
            $query->where('flat_id', $request->flat_id);
        }
    
        // Filter by maintenance's from_date
        if ($request->filled('from_date')) {
            $query->whereHas('maintenance', function ($q) use ($request) {
                $q->whereDate('from_date', '>=', $request->from_date);
            });
        }
    
        // Filter by maintenance's to_date
        if ($request->filled('to_date')) {
            $query->whereHas('maintenance', function ($q) use ($request) {
                $q->whereDate('to_date', '<=', $request->to_date);
            });
        }
    
        $maintenance_payments = $query->orderBy('created_at', 'desc')->with(['flat','user','maintenance'])->get();
        $total_payment = 0;
        $total_gst = 0;
        foreach ($maintenance_payments as $payment) {
            $maintenance = $payment->maintenance;
            $late_fine = 0;

            if ($maintenance && $maintenance->due_date < now()) {
                $late_days = now()->diffInDays(Carbon::parse($maintenance->due_date));

                switch ($maintenance->late_fine_type) {
                    case 'Daily':
                        $late_fine = $late_days * $maintenance->late_fine_value;
                        break;
                    case 'Fixed':
                        $late_fine = $maintenance->late_fine_value;
                        break;
                    case 'Percentage':
                        $late_fine = ($payment->dues_amount * $maintenance->late_fine_value) / 100;
                        break;
                }
            }

            $payment->late_fine = $late_fine;
            // $payment->total_amount = $maintenance->amount + $late_fine;
            $total = $payment->dues_amount + $late_fine;
            $payment->save();
            $payment->gst = $total * $payment->maintenance->gst / 100;
            $total_payment += $total;
            $total_gst += $payment->gst;
        }

        $gst = $total_gst;
        $grand_total = $total_payment + $gst;
        
        return response()->json([
            'maintenance_payments' => $maintenance_payments,
            'blocks' => $blocks,
            'flat_id' => $flat_id,
        ], 200);
    }
    
    public function pay_maintenance(Request $request)
    {
        $flat = Flat::where('id',$request->flat_id)->where('building_id',Auth::User()->building_id)->first();
        
        if(!$flat){
            return response()->json([
                'msg' => 'Flat not found',
            ], 422);
        }
        if($flat->living_status == 'Owner'){
            $user = $flat->owner;
        }else{
            $user = $flat->tanent;
        }
        $last_payment = MaintenancePayment::where('flat_id', $flat->id)
            ->where('status', 'Paid')
            ->orderBy('id', 'desc')
            ->first();
        $last_paid_date = $last_payment ? $last_payment->created_at->format('Y-m-d') : 'N/A';

        $maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
            ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building'])
            ->where('status', 'Unpaid')
            ->orderBy('id', 'desc')
            ->get();

        $total_payment = 0;
        $total_gst = 0;
        foreach ($maintenance_payments as $payment) {
            $maintenance = $payment->maintenance;
            $late_fine = 0;

            if ($maintenance && $maintenance->due_date < now()) {
                $late_days = now()->diffInDays(Carbon::parse($maintenance->due_date));

                switch ($maintenance->late_fine_type) {
                    case 'Daily':
                        $late_fine = $late_days * $maintenance->late_fine_value;
                        break;
                    case 'Fixed':
                        $late_fine = $maintenance->late_fine_value;
                        break;
                    case 'Percentage':
                        $late_fine = ($payment->dues_amount * $maintenance->late_fine_value) / 100;
                        break;
                }
            }

            $payment->late_fine = $late_fine;
            // $payment->total_amount = $maintenance->amount + $late_fine;
            $total = $payment->dues_amount + $late_fine;
            $payment->save();
            $payment->gst = $total * $payment->maintenance->gst / 100;
            $total_payment += $total;
            $total_gst += $payment->gst;
        }

        $gst = $total_gst;
        $grand_total = $total_payment + $gst;
        $grand_total = ceil($grand_total);
        // $paid_maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
        //     ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building','transaction'])
        //     ->where('status', 'Paid')
        //     ->orderBy('id', 'desc')
        //     ->get();
        $transactions = Transaction::where('user_id',$user->id)->where('model','Maintenance')->with(['user','maintenance_payments.maintenance'])->orderBy('id','desc')->get();
        return response()->json([
                'flat' => $flat,
                'maintenance_payments' => $maintenance_payments,
                'transactions' => $transactions,
                'total_payment' => $total_payment,
                'gst' => $gst,
                'grand_total' => $grand_total,
                'last_paid_date' => $last_paid_date,
                'user' => $user,
        ], 200);
    }
    
    public function pay_maintenance_bill(Request $request)
    {
        $flat = Flat::where('id',$request->flat_id)->where('building_id',Auth::User()->building_id)->first();
        
        if(!$flat){
            return response()->json([
                'error' => 'Flat not found',
            ], 422);
        }
        if($flat->tanent){
            $user = $flat->tanent;
        }else{
            $user = $flat->owner;
        }
        
        $last_payment = MaintenancePayment::where('flat_id', $flat->id)
            ->where('status', 'Paid')
            ->orderBy('id', 'desc')
            ->first();
        $last_paid_date = $last_payment ? $last_payment->created_at->format('Y-m-d') : 'N/A';

        $maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
            ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building'])
            ->where('status', 'Unpaid')
            ->orderBy('id', 'desc')
            ->get();
        if($maintenance_payments->isEmpty()){
            return response()->json([
                'error' => 'No maintenance payment found',
            ], 422);
        }
        $total_payment = 0;
        $total_gst = 0;
        foreach ($maintenance_payments as $payment) {
            $maintenance = $payment->maintenance;
            $late_fine = 0;

            if ($maintenance && $maintenance->due_date < now()) {
                $late_days = now()->diffInDays(Carbon::parse($maintenance->due_date));

                switch ($maintenance->late_fine_type) {
                    case 'Daily':
                        $late_fine = $late_days * $maintenance->late_fine_value;
                        break;
                    case 'Fixed':
                        $late_fine = $maintenance->late_fine_value;
                        break;
                    case 'Percentage':
                        $late_fine = ($payment->dues_amount * $maintenance->late_fine_value) / 100;
                        break;
                }
            }

            $payment->late_fine = $late_fine;
            // $payment->total_amount = $maintenance->amount + $late_fine;
            $total = $payment->dues_amount + $late_fine;
            $payment->save();
            $payment->gst = $total * $payment->maintenance->gst / 100;
            $total_payment += $total;
            $total_gst += $payment->gst;
        }
        $gst = $total_gst;
        $grand_total = $total_payment + $gst;
        // $paid_maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
        //     ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building','transaction'])
        //     ->where('status', 'Paid')
        //     ->orderBy('id', 'desc')
        //     ->get();
        $transactions = Transaction::where('user_id',$user->id)->where('model','Maintenance')->with(['user','maintenance_payments.maintenance'])->orderBy('id','desc')->get();
        if(ceil($request->amount) != ceil($grand_total)){
            return response()->json([
                'error' => 'Paying amount doesnt match to current bill',
            ], 422);
        }
            $transaction = new Transaction();
            $transaction->building_id = Auth::User()->building_id;
            $transaction->user_id = $user->id;
            $transaction->order_id = '';
            $transaction->model = 'Maintenance';
            $paid_maintenance = MaintenancePayment::where('flat_id',$flat->id)->orderBy('id','desc')->first();
            $transaction->model_id = $paid_maintenance->maintenance_id;
            $transaction->type = 'Credit';
            $transaction->payment_type = $request->payment_type;
            $transaction->amount = $request->amount;
            $transaction->reciept_no = rand();
            $transaction->desc = 'Maintenance Payment paid by flat number '.$flat->name .' Through Accounts:'.Auth::User()->name;
            $transaction->status = 'Success';
            $transaction->date = now()->toDateString();
            $transaction->save();
            
            $maintenance_payment = $paid_maintenance;
            $maintenance_payment->user_id = $user->id;
            $maintenance_payment->paid_amount = $maintenance_payment->dues_amount;
            $maintenance_payment->paid_date = now()->toDateString();
            $maintenance_payment->dues_amount = 0;
            $maintenance_payment->type = 'Credit';
            $maintenance_payment->payment_type = $request->payment_type;
            $maintenance_payment->desc = 'Maintenance Payment paid by flat number '.$flat->name .' Through Accounts:'.Auth::User()->name;
            $maintenance_payment->transaction_id = $transaction->id;
            $maintenance_payment->status = 'Paid';
            $maintenance_payment->save();

            $maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
            // ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building'])
            ->where('status', 'Unpaid')
            ->orderBy('id', 'desc')
            ->get();
            
            foreach($maintenance_payments as $maintenance_payment){
                $maintenance_payment->paid_amount = $maintenance_payment->dues_amount;
                $maintenance_payment->paid_date = now()->toDateString();
                $maintenance_payment->dues_amount = 0;
                $maintenance_payment->type = 'Credit';
                $maintenance_payment->payment_type = $request->payment_type;
                $maintenance_payment->desc = 'Paid Through Accounts';
                $maintenance_payment->transaction_id = $transaction->id;
                $maintenance_payment->status = 'Paid';
                $maintenance_payment->save();
            }
            
        // Check if user has a device token
                $tanent = $flat->tanent;
                $owner = $flat->owner;
                
                $usersToNotify = collect([$tanent, $owner])->filter();

                foreach ($usersToNotify as $targetUser) {
                    if ($targetUser && $targetUser->fcm_token) {
                        $factory = (new Factory)
                            ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json'));
                
                        $messaging = $factory->createMessaging();
                
                        $notification = Notification::create(
                            'Maintenance Payment Successful',
                            'A new maintenance payment has been paid by the Accounts. Please check the details.'
                        );
                
                        $dataPayload = [
                            'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                            'screen' => 'MaintenancePage',
                            'params' => json_encode(['maintenanceId' => $maintenance->id]),
                            'categoryId' => '',
                            'channelId' => '',
                            'sound' => 'bellnotificationsound.wav',
                            'type' => 'MAINTENANCE_PAID',
                            'user_id' => (string)$targetUser->id,
                        ];
                
                        $message = CloudMessage::withTarget('token', $targetUser->fcm_token)
                            ->withNotification($notification)
                            ->withData($dataPayload);
                
                        try {
                            $messaging->send($message);
                        } catch (MessagingException $e) {
                            \Log::error("FCM Error for user {$targetUser->id}: " . $e->getMessage());
                            // Optionally continue notifying others instead of returning early
                        }
                    }
                }
        return response()->json([
            'success' => 'Payment recieved successfully',
        ], 200); 

    }
    
    public function maintenance_invoice(Request $request)
    {
        $rules = [
            'maintenance_payment_id' => 'required|exists:maintenance_payments,id',
        ];
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            
            return response()->json([
                'error' => $validation->errors()->first()
            ],422);
        }
        $maintenance_payment_id = $request->maintenance_payment_id;
        $maintenance_payment = MaintenancePayment::where('id',$maintenance_payment_id)->where('building_id',Auth::User()->building_id)->first();
        if(!$maintenance_payment){
            return response()->json([
                'error' => 'Maintenance payment not found'
            ],422);
        }
        $flat = $maintenance_payment->flat;
        if($flat->tanent){
            $user = $flat->tanent;
        }else{
            $user = $flat->owner;
        }
        
        $last_payment = MaintenancePayment::where('flat_id', $flat->id)
            ->where('status', 'Paid')
            ->where('id', '<', $maintenance_payment_id)
            ->orderBy('id', 'desc')
            ->first();
        $last_paid_date = $last_payment ? $last_payment->created_at->format('Y-m-d') : 'N/A';
        
        $transaction = $maintenance_payment->transaction;
        $maintenance_payments = $transaction->maintenance_payments()
            ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building'])
            ->orderBy('id', 'desc')
            ->get();

        $total_payment = 0;
        $total_gst = 0;
        foreach ($maintenance_payments as $payment) {
            $maintenance = $payment->maintenance;
            $late_fine = 0;

            if ($maintenance && $maintenance->due_date < now()) {
                $late_days = now()->diffInDays(Carbon::parse($maintenance->due_date));

                switch ($maintenance->late_fine_type) {
                    case 'Daily':
                        $late_fine = $late_days * $maintenance->late_fine_value;
                        break;
                    case 'Fixed':
                        $late_fine = $maintenance->late_fine_value;
                        break;
                    case 'Percentage':
                        $late_fine = ($payment->paid_amount * $maintenance->late_fine_value) / 100;
                        break;
                }
            }

            $payment->late_fine = $late_fine;
            // $payment->total_amount = $maintenance->amount + $late_fine;
            $total = $payment->paid_amount + $late_fine;
            $payment->save();
            $payment->gst = $total * $payment->maintenance->gst / 100;
            $total_payment += $total;
            $total_gst += $payment->gst;
        }

        $gst = $total_gst;
        $grand_total = $total_payment + $gst;
        // $paid_maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
        //     ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building','transaction'])
        //     ->where('status', 'Paid')
        //     ->orderBy('id', 'desc')
        //     ->get();
        $transactions = Transaction::where('user_id',$user->id)->where('model','Maintenance')->with(['user','maintenance_payments.maintenance'])->orderBy('id','desc')->get();
        
        $pdf = Pdf::loadView('partials.invoice.maintenance', [
            'flat' => $flat,
            'maintenance_payments' => $maintenance_payments,
            'transactions' => $transactions,
            'total_payment' => $total_payment,
            'gst' => $gst,
            'grand_total' => $grand_total,
            'last_paid_date' => $last_paid_date,
            'user' => $user,
        ]);

        return $pdf->download('invoice.pdf');
    
        // return view('partials.invoice.maintenance',compact('flat','maintenance_payments','transactions','total_payment','gst','grand_total','last_paid_date','user'));
    }
    
    public function maintenance_reciept(Request $request)
    {
        $maintenance_payment_id = $request->maintenance_payment_id;
        $maintenance_payment = MaintenancePayment::where('id',$maintenance_payment_id)->where('building_id',Auth::User()->building_id)->first();

        if(!$maintenance_payment){
            return response()->json([
                'error' => 'Maintenance payment not found'
            ],422);
        }
        $flat = $maintenance_payment->flat;
        if($flat->tanent){
            $user = $flat->tanent;
        }else{
            $user = $flat->owner;
        }
        
        $last_payment = MaintenancePayment::where('flat_id', $flat->id)
            ->where('status', 'Paid')
            ->where('id', '<', $maintenance_payment_id)
            ->orderBy('id', 'desc')
            ->first();
        $last_paid_date = $last_payment ? $last_payment->created_at->format('Y-m-d') : 'N/A';
        
        $transaction = $maintenance_payment->transaction;
        $maintenance_payments = $transaction->maintenance_payments()
            ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building'])
            ->orderBy('id', 'desc')
            ->get();

        $total_payment = 0;
        $total_gst = 0;
        foreach ($maintenance_payments as $payment) {
            $maintenance = $payment->maintenance;
            $late_fine = 0;

            if ($maintenance && $maintenance->due_date < now()) {
                $late_days = now()->diffInDays(Carbon::parse($maintenance->due_date));

                switch ($maintenance->late_fine_type) {
                    case 'Daily':
                        $late_fine = $late_days * $maintenance->late_fine_value;
                        break;
                    case 'Fixed':
                        $late_fine = $maintenance->late_fine_value;
                        break;
                    case 'Percentage':
                        $late_fine = ($payment->paid_amount * $maintenance->late_fine_value) / 100;
                        break;
                }
            }

            $payment->late_fine = $late_fine;
            // $payment->total_amount = $maintenance->amount + $late_fine;
            $total = $payment->paid_amount + $late_fine;
            $payment->save();
            $payment->gst = $total * $payment->maintenance->gst / 100;
            $total_payment += $total;
            $total_gst += $payment->gst;
        }

        $gst = $total_gst;
        $grand_total = $total_payment + $gst;
        // $paid_maintenance_payments = MaintenancePayment::where('flat_id', $flat->id)
        //     ->with(['maintenance', 'flat.owner', 'flat.tanent', 'flat.block', 'flat.building','transaction'])
        //     ->where('status', 'Paid')
        //     ->orderBy('id', 'desc')
        //     ->get();
        $transactions = Transaction::where('user_id',$user->id)->where('model','Maintenance')->with(['user','maintenance_payments.maintenance'])->orderBy('id','desc')->get();
        
        $pdf = Pdf::loadView('partials.reciept.maintenance', [
            'flat' => $flat,
            'maintenance_payments' => $maintenance_payments,
            'transactions' => $transactions,
            'total_payment' => $total_payment,
            'gst' => $gst,
            'grand_total' => $grand_total,
            'last_paid_date' => $last_paid_date,
            'user' => $user,
        ]);

        return $pdf->download('reciept.pdf');
        // return view('admin.account.maintenance.reciept_maintenance',compact('flat','maintenance_payments','transactions','total_payment','gst','grand_total','last_paid_date','user'));
    }
    
    public function add_new_event(Request $request)
    {
        $rules = [
            'name' => 'required|max:65',
            'desc' => 'required|max:200',
            'from_time' => 'required',
            'to_time' => 'required',
            'is_payment_enabled' => 'required|in:Yes,No',
            'status' => 'required|in:Active,Pending',
            'image' => 'nullable|image|max:2048',
        ];
    
        $msg = 'Event added Susccessfully';
        $event = new Event();
    
        if ($request->event_id) {
            $event = Event::withTrashed()->find($request->event_id);
            $msg = 'Event updated Susccessfully';
        }
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ],422);
        }
        
        $user = Auth::user();
        $building = $user->building;
        
        // if($request->hasFile('image')) {
        //     $file= $request->file('image');
        //     $allowedfileExtension=['jpeg','jpeg','png'];
        //     $extension = $file->getClientOriginalExtension();
        //     Storage::disk('s3')->delete($event->getImageFilenameAttribute());
        //     $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        //     $filename = 'images/events/' . uniqid() . '.' . $extension;
        //     Storage::disk('s3')->put($filename, file_get_contents($file));
        //     $event->image = $filename;
        // }
        
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $allowedfileExtension = ['jpeg', 'jpg', 'png'];
            $extension = $file->getClientOriginalExtension();
            if (!empty($event->photo_filename)) {
                $file_path = public_path('images/' . $event->image_filename);
            
                if (is_file($file_path)) {
                    unlink($file_path);
                }
            }

            $filename = 'events/' . uniqid() . '.' . $extension;
            $path = $file->move(public_path('/images/events/'), $filename);
            $event->image = $filename;
        }
        
        $event->building_id = $building->id;
        $event->name = $request->name;
        $event->desc = $request->desc;
        $event->from_time = $request->from_time;
        $event->to_time = $request->to_time;
        $event->is_payment_enabled = $request->is_payment_enabled;
        $event->status = $request->status;
        $event->save();
        
        foreach($building->flats as $flat){
            // Check if user has a device token
                $tanent = $flat->tanent;
                $owner = $flat->owner;
                
                $usersToNotify = collect([$tanent, $owner])->filter();

                foreach ($usersToNotify as $targetUser) {
                    if ($targetUser && $targetUser->fcm_token) {
                        $factory = (new Factory)
                            ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json'));
                
                        $messaging = $factory->createMessaging();
                
                        $notification = Notification::create(
                            'New Event Added',
                            'A new event has been added by the BA. Please check the details and participate.'
                        );
                
                        $dataPayload = [
                            'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                            'screen' => 'Timeline',
                            'params' => json_encode(['ScreenTab' => 'Events']),
                            'categoryId' => '',
                            'channelId' => '',
                            'sound' => 'bellnotificationsound.wav',
                            'type' => 'EVENT_ADDED',
                            'user_id' => (string)$targetUser->id,
                        ];
                
                        $message = CloudMessage::withTarget('token', $targetUser->fcm_token)
                            ->withNotification($notification)
                            ->withData($dataPayload);
                
                        try {
                            $messaging->send($message);
                        } catch (MessagingException $e) {
                            \Log::error("FCM Error for user {$targetUser->id}: " . $e->getMessage());
                            // Optionally continue notifying others instead of returning early
                        }
                    }
                }
        }
    
        return response()->json([
                'msg' => $msg
            ],200);
    }
    
    public function get_events(Request $request)
    {
        $building = Auth::User()->building;
        $events = $building->events;
        return response()->json([
            'events' => $events
        ],200);
    }
    
    public function event_payments(Request $request)
    {
        $rules = [
            'event_id' => 'required|exists:events,id',
        ];
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ],422);
        }
        $building = Auth::User()->building;
        $event = Event::where('id',$request->event_id)->with(['payments.user'])->first();
        return response()->json([
            'event' => $event
        ],200);
    }
    
    public function store_event_payment(Request $request)
    {
        $rules = [
            'event_id' => 'required|exists:events,id',
            'user_id' => 'required|exists:users,id',
            'payment_type' => 'required|in:InHand,InBank',
            'amount' => 'required',
            'status' => 'required|in:Paid',
        ];
        $event = Event::find($request->event_id);
        $user = User::find($request->user_id);
        $msg = 'Payment added Susccessfully';
        $payment = new Payment();
    
        if ($request->id) {
            $payment = Payment::withTrashed()->find($request->id);
            $msg = 'Payment added Susccessfully';
        }
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ],200);
        }
        
        $payment->event_id = $request->event_id;
        $payment->building_id = Auth::User()->building_id;
        $payment->user_id = $request->user_id;
        $payment->type = 'Credit';
        $payment->payment_type = $request->payment_type;
        $payment->amount = $request->amount;
        $payment->date = $request->date;
        $payment->status = $request->status;
        $payment->save();

        $transaction = new Transaction();
            $transaction->building_id = Auth::User()->building_id;
            $transaction->user_id = $request->user_id;
            $transaction->model = 'Event';
            $transaction->model_id = $request->event_id;
            $transaction->type = 'Credit';
            $transaction->payment_type = $request->payment_type;
            $transaction->amount = $request->amount;
            $transaction->reciept_no = (string) $payment->id .'-RCP-'.rand(100000,999999);
            $transaction->desc = 'Event Payment for '.$event->name.'  paid by '.$user->name.' through BA';
            $transaction->status = 'Success';
            $transaction->date = $request->date;
            $transaction->save();
            
        $payment->transaction_id = $transaction->id;
        $payment->save();
        
        // Check if user has a device token


                    if ($user && $user->fcm_token) {
                        $factory = (new Factory)
                            ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json'));
                
                        $messaging = $factory->createMessaging();
                
                        $notification = Notification::create(
                            'Event Payment Successful',
                            'Your payment of ₹'.$request->amount.' for the event was successful. You can now download your payment receipt.'
                        );
                
                        $dataPayload = [
                            'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                            'screen' => 'EventsFundList',
                            'params' => json_encode(['eventID' => $event->id]),
                            'categoryId' => '',
                            'channelId' => '',
                            'sound' => 'bellnotificationsound.wav',
                            'type' => 'MAINTENANCE_PAID',
                            'user_id' => (string)$user->id,
                        ];
                
                        $message = CloudMessage::withTarget('token', $user->fcm_token)
                            ->withNotification($notification)
                            ->withData($dataPayload);
                
                        try {
                            $messaging->send($message);
                        } catch (MessagingException $e) {
                            \Log::error("FCM Error for user {$user->id}: " . $e->getMessage());
                            // Optionally continue notifying others instead of returning early
                        }
                    }

        return response()->json([
            'success' => $msg
        ],200);
    }
    
    public function get_user_by_email(Request $request) {
        $user = User::where('email', $request->email)->orWhere('phone', $request->email)->where('status','Active')->first();
        if ($user) {
            return response()->json(['success' => true, 'data' => ['id' => $user->id,'name' => $user->name]],200);
        }
        return response()->json(['success' => false, 'message' => 'User not found'],422);
    }
    
    public function event_reciept(Request $request)
    {
        $payment = Payment::where('id',$request->payment_id)->where('building_id',Auth::User()->building_id)->first();

        if(!$payment){
            return response()->json([
                'error' => 'Event payment not found'
            ]);
        }
        $pdf = Pdf::loadView('partials.reciept.event', [
            'payment' => $payment,
        ]);

        return $pdf->download('event-reciept.pdf');
    }
    
    public function get_essentials(Request $request)
    {
        $building = Auth::User()->building;
        $essentials = $building->essentials;
        
        return response()->json([
            'essentials' => $essentials
        ],200);
    }
    
    public function store_essential(Request $request)
    {
        $rules = [
            'essential_id' => 'nullable|exists:essentials,id',
            'reason' => 'required',
            'amount' => 'required',
            'status' => 'required|in:Active,Inactive',
            'due_date' => 'required',
            'late_fine_type' => 'required|in:Percentage,Daily,Fixed',
            'late_fine_value' => 'required|int',
            'gst' => 'required|int',
        ];
    
        $msg = 'Essential added Susccessfully';
        $essential = new Essential();
    
        if ($request->essential_id) {
            $essential = Essential::withTrashed()->find($request->essential_id);
            $msg = 'Essential updated Susccessfully';
        }
    
        $validation = \Validator::make($request->all(), $rules);
    
        if ($validation->fails()) {
            return response()->json([
                'error' => $validation->errors()->first()
            ]);
        }
        $user = Auth::User();
        $essential->user_id = $user->id;
        $essential->building_id = $user->building_id;
        $essential->reason = $request->reason;
        $essential->amount = $request->amount;
        $essential->due_date = $request->due_date;
        $essential->late_fine_type = $request->late_fine_type;
        $essential->late_fine_value = $request->late_fine_value;
        $essential->gst = $request->gst;
        $essential->status = $request->status;
        $essential->save();
        
        foreach($user->building->flats as $flat)
        {
            if($flat->owner_id > 0){
                $essential_payment = new EssentialPayment();
                if($request->id) {
                    $essential_payment = EssentialPayment::where('essential_id',$essential->id)
                    ->where('flat_id',$flat->id)->where('status','Unpaid')->first();
                }
                if($essential_payment){
                    $essential_payment->essential_id = $essential->id;
                    $essential_payment->building_id = $essential->building_id;
                    $essential_payment->flat_id = $flat->id;
                    $essential_payment->user_id = $flat->owner_id;
                    $essential_payment->paid_amount = 0;
                    $essential_payment->dues_amount = $essential->amount;
                    $essential_payment->bill_no = 'ESSE-'.rand(100000,999999);
                    $essential_payment->type = 'Created';
                    $essential_payment->status = 'Unpaid';
                    $essential_payment->save();
                }
            }
            
            // Check if user has a device token
                $tanent = $flat->tanent;
                $owner = $flat->owner;
                
                $usersToNotify = collect([$tanent, $owner])->filter();

                foreach ($usersToNotify as $targetUser) {
                    if ($targetUser && $targetUser->fcm_token) {
                        $factory = (new Factory)
                            ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json'));
                
                        $messaging = $factory->createMessaging();
                
                        $notification = Notification::create(
                            'New Essential Payment Added',
                            'A new essential payment has been added by the BA. Please review the details and proceed with the payment.'
                        );
                
                        $dataPayload = [
                            'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                            'screen' => 'EssentialsList',
                            'params' => json_encode(['essentialsID' => $essential->id]),
                            'categoryId' => '',
                            'channelId' => '',
                            'sound' => 'bellnotificationsound.wav',
                            'type' => 'ESSENTIAL_ADDED',
                            'user_id' => (string)$targetUser->id,
                        ];
                
                        $message = CloudMessage::withTarget('token', $targetUser->fcm_token)
                            ->withNotification($notification)
                            ->withData($dataPayload);
                
                        try {
                            $messaging->send($message);
                        } catch (MessagingException $e) {
                            \Log::error("FCM Error for user {$targetUser->id}: " . $e->getMessage());
                            // Optionally continue notifying others instead of returning early
                        }
                    }
                }
        }
        return response()->json([
            'msg' => $msg
        ],200);
    }
    

    
    
    public function essential_payments(Request $request)
    {
    $rules = [
        'essential_id' => 'required|exists:essentials,id',
    ];

    $validation = \Validator::make($request->all(), $rules);

    if ($validation->fails()) {
        return response()->json([
            'error' => $validation->errors()->first()
        ]);
    }

    $building = Auth::user()->building;

    $essential = Essential::where('id', $request->essential_id)
        ->where('building_id', $building->id)
        ->with(['payments.user'])
        ->first();

    if (!$essential) {
        return response()->json([
            'error' => 'Essential not found'
        ]);
    }

    foreach ($essential->payments as $essential_payment) {
        $dues_amount = $essential_payment->dues_amount;
        $late_fine = 0;
        $gst = $essential_payment->essential->gst;

        if ($essential_payment && $essential_payment->essential->due_date < now()) {
            $late_days = now()->diffInDays(Carbon::parse($essential_payment->essential->due_date));

            switch ($essential_payment->essential->late_fine_type) {
                case 'Daily':
                    $late_fine = $late_days * $essential_payment->essential->late_fine_value;
                    break;
                case 'Fixed':
                    $late_fine = $essential_payment->essential->late_fine_value;
                    break;
                case 'Percentage':
                    $late_fine = ($essential_payment->dues_amount * $essential_payment->essential->late_fine_value) / 100;
                    break;
            }
        }

        $total_amount = $dues_amount + $late_fine;
        $total_gst = $total_amount * $gst / 100;
        $grand_total = $total_amount + $total_gst;

        // Add grand_total attribute dynamically to the payment model
        $essential_payment['grand_total'] = ceil($grand_total);
    }

    return response()->json([
        'essential' => $essential
    ], 200);
}

    
 public function store_essential_payment(Request $request)
{
    $rules = [
        'essential_payment_id' => 'required|exists:essential_payments,id',
        'amount' => 'required',
        'payment_type' => 'required|in:InHand,InBank',
        'status' => 'required|in:Paid',
    ];

    $msg = 'Essential payment added Successfully';
    $essential_payment = new EssentialPayment();

    if ($request->essential_payment_id) {
        $essential_payment = EssentialPayment::where('id', $request->essential_payment_id)->withTrashed()->first();
        $msg = 'Essential payment updated Successfully';
    }

    $validation = \Validator::make($request->all(), $rules);

    if ($validation->fails()) {
        return response()->json([
            'error' => $validation->errors()->first()
        ], 422);
    }

    $flat = $essential_payment->flat;

    if ($essential_payment->status == 'Paid') {
        return response()->json([
            'error' => 'Payment already completed'
        ], 422);
    }

    $dues_amount = $essential_payment->dues_amount;
    $late_fine = 0;
    $gst = $essential_payment->essential->gst;

    if ($essential_payment && $essential_payment->essential->due_date < now()) {
        $late_days = now()->diffInDays(Carbon::parse($essential_payment->essential->due_date));

        switch ($essential_payment->essential->late_fine_type) {
            case 'Daily':
                $late_fine = $late_days * $essential_payment->essential->late_fine_value;
                break;
            case 'Fixed':
                $late_fine = $essential_payment->essential->late_fine_value;
                break;
            case 'Percentage':
                $late_fine = ($essential_payment->dues_amount * $essential_payment->essential->late_fine_value) / 100;
                break;
        }
    }

    $total_amount = $dues_amount + $late_fine;
    $total_gst = $total_amount * $gst / 100;
    $grand_total = $total_amount + $total_gst;

    if ($request->amount != ceil($grand_total)) {
        return response()->json([
            'error' => 'Essential payment amount does not match the current bill'
        ], 422);
    }

    $essential_payment->paid_amount = $grand_total;
    $essential_payment->dues_amount = 0;
    $essential_payment->type = 'Credit';
    $essential_payment->payment_type = $request->payment_type;
    $essential_payment->date = now()->toDateString();
    $essential_payment->status = 'Paid';
    $essential_payment->save();

    $user = $flat->owner;

    $transaction = new Transaction();
    $transaction->building_id = Auth::user()->building_id;
    $transaction->user_id = $user->id;
    $transaction->order_id = '';
    $transaction->model = 'Essential';
    $transaction->model_id = $request->essential_id;
    $transaction->type = 'Credit';
    $transaction->payment_type = $request->payment_type;
    $transaction->amount = $request->amount;
    $transaction->reciept_no = rand();
    $transaction->desc = 'Essential Payment paid by flat number ' . $user->flat->name . ' Through BA:' . Auth::user()->name;
    $transaction->status = 'Success';
    $transaction->date = now()->toDateString();
    $transaction->save();

    $essential_payment->transaction_id = $transaction->id;
    $essential_payment->save();

    // Send FCM notification if user has token
    if ($user && $user->fcm_token) {
        $factory = (new Factory)
            ->withServiceAccount(base_path('myflatinfo-firebase-adminsdk.json'));

        $messaging = $factory->createMessaging();

        $notification = Notification::create(
            'Essential Payment Successful',
            'Your payment of ₹' . $request->amount . ' for the essential was successful. You can now download your payment receipt.'
        );

        $dataPayload = [
            'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
            'screen' => 'EssentialsList',
            'params' => json_encode(['essentialsID' => $essential_payment->essential_id]),
            'categoryId' => '',
            'channelId' => '',
            'sound' => 'bellnotificationsound.wav',
            'type' => 'MAINTENANCE_PAID',
            'user_id' => (string)$user->id,
        ];

        $message = CloudMessage::withTarget('token', $user->fcm_token)
            ->withNotification($notification)
            ->withData($dataPayload);

        try {
            $messaging->send($message);
        } catch (MessagingException $e) {
            \Log::error("FCM Error for user {$user->id}: " . $e->getMessage());
        }
    }

    return response()->json([
        'msg' => $msg
    ], 200);
}

    
    public function essential_invoice(Request $request)
    {
        $payment_id = $request->essential_payment_id;
        $essential_payment = EssentialPayment::where('id',$payment_id)->where('building_id',Auth::User()->building_id)->first();
        
        if(!$essential_payment){
            return response()->json([
                'error' => 'Essential payment not found'
            ],422);
        }
        $flat = $essential_payment->flat;
        if($flat->tanent){
            $user = $flat->tanent;
        }else{
            $user = $flat->owner;
        }

        $dues_amount = $essential_payment->essential->amount;
        $late_fine = 0;
        $gst = $essential_payment->essential->gst;
        if ($essential_payment && $essential_payment->essential->due_date < now()) {
            $late_days = now()->diffInDays(Carbon::parse($essential_payment->essential->due_date));
            switch ($essential_payment->essential->late_fine_type) {
                case 'Daily':
                    $late_fine = $late_days * $essential_payment->essential->late_fine_value;
                    break;
                case 'Fixed':
                    $late_fine = $essential_payment->essential->late_fine_value;
                    break;
                case 'Percentage':
                    if($essential_payment->status == 'Paid'){
                        $late_fine = ($essential_payment->paid_amount * $essential_payment->essential->late_fine_value) / 100;
                    }else{
                        $late_fine = ($dues_amount * $essential_payment->essential->late_fine_value) / 100;
                    }
                    break;
                }
        }
        $payment = $essential_payment;
        $total_amount = $dues_amount + $late_fine;
        $total_gst = $total_amount * $gst / 100;
        $grand_total = $total_amount + $total_gst;
        $pdf = Pdf::loadView('partials.invoice.essential', [
            'flat' => $flat,
            'payment' => $payment,
            'late_fine' => $late_fine,
            'total_gst' => $total_gst,
            'grand_total' => $grand_total,
            'user' => $user,
        ]);

        return $pdf->download('invoice.pdf');
    }
    
    public function essential_reciept(Request $request)
    {
        $payment_id = $request->essential_payment_id;
        $essential_payment = EssentialPayment::where('id',$payment_id)->where('building_id',Auth::User()->building_id)->first();
        
        if(!$essential_payment){
            return response()->json([
                'error' => 'Essential payment not found'
            ], 422);
            
        }
        $flat = $essential_payment->flat;
        if($flat->tanent){
            $user = $flat->tanent;
        }else{
            $user = $flat->owner;
        }

        $dues_amount = $essential_payment->essential->amount;
        $late_fine = 0;
        $gst = $essential_payment->essential->gst;
        if ($essential_payment && $essential_payment->essential->due_date < now()) {
            $late_days = now()->diffInDays(Carbon::parse($essential_payment->essential->due_date));
            switch ($essential_payment->essential->late_fine_type) {
                case 'Daily':
                    $late_fine = $late_days * $essential_payment->essential->late_fine_value;
                    break;
                case 'Fixed':
                    $late_fine = $essential_payment->essential->late_fine_value;
                    break;
                case 'Percentage':
                    if($essential_payment->status == 'Paid'){
                        $late_fine = ($essential_payment->paid_amount * $essential_payment->essential->late_fine_value) / 100;
                    }else{
                        $late_fine = ($essential_payment->dues_amount * $essential_payment->essential->late_fine_value) / 100;
                    }
                    break;
                }
        }
        $payment = $essential_payment;
        $total_amount = $dues_amount + $late_fine;
        $total_gst = $total_amount * $gst / 100;
        $grand_total = $total_amount + $total_gst;
        
        $pdf = Pdf::loadView('partials.reciept.essential', [
            'flat' => $flat,
            'payment' => $payment,
            'late_fine' => $late_fine,
            'total_gst' => $total_gst,
            'grand_total' => $grand_total,
            'user' => $user,
        ]);

        return $pdf->download('reciept-essential.pdf');
        
    }
    
    public function get_bookings(Request $request)
    {
        $user = Auth::user();
        $building = $user->building;
    
        $query = Booking::where('building_id', $building->id)
            ->with(['user.flat','timing', 'facility']);
    
        // Apply from_date and to_date filters if provided
        if ($request->filled('from_date') && $request->filled('to_date')) {
            try {
                $from = Carbon::parse($request->from_date)->startOfDay();
                $to = Carbon::parse($request->to_date)->endOfDay();
    
                $query->whereBetween('date', [$from->toDateString(), $to->toDateString()]);
            } catch (\Exception $e) {
                return response()->json(['status' => 'error', 'error' => 'Invalid date format.'], 422);
            }
        }
    
        $bookings = $query->get()
            ->groupBy('reciept_no')
            ->map(function ($groupedBookings, $recieptNo) {
                return [
                    'reciept_no' => $recieptNo,
                    'bookings' => $groupedBookings->map(function ($booking) {
                        $booking->timing->dates = is_string($booking->timing->dates)
                            ? json_decode($booking->timing->dates, true)
                            : $booking->timing->dates;
                        return $booking;
                    }),
                    'transaction' => optional($groupedBookings->first()->transaction),
                    'order' => optional($groupedBookings->first()->order),
                    'facility' => optional($groupedBookings->first()->facility),
                ];
            })
            ->values();
    
        // $facilities = $building->facilities()->select(['id', 'name'])->get();
    
        return response()->json([
            'bookings' => $bookings
        ], 200);
    }


    
    public function get_facilities(Request $request)
    {
        $building = Auth::User()->building;
        $facilities = $building->facilities()->select(['id', 'name'])->get();
        return response()->json([
            'facilities' => $facilities
        ], 200);
    }


    
    public function society_fund(Request $request)
    {
        $user = Auth::user();
        $building = $user->building;
    
        $transactionsQuery = Transaction::where('building_id', $building->id);
    
        // Filter by model and model_id
        if ($request->filled('model')) {
            $transactionsQuery->where('model', $request->model);
    
            if ($request->filled('model_id')) {
                $transactionsQuery->where('model_id', $request->model_id);
            }
        }
    
        // Filter by from_date and to_date
        if ($request->filled('from_date')) {
            $transactionsQuery->whereDate('date', '>=', $request->from_date);
        }
    
        if ($request->filled('to_date')) {
            $transactionsQuery->whereDate('date', '<=', $request->to_date);
        }
    
        $transactions = $transactionsQuery->get();
        
        // Initialize totals
        $total_debit = 0;
        $total_credit = 0;
        $inhand = 0;
        $inbank = 0;
    
        foreach ($transactions as $transaction) {
            if ($transaction->type === 'Debit') {
                $total_debit += $transaction->amount;
            } elseif ($transaction->type === 'Credit') {
                $total_credit += $transaction->amount;
            }
    
            if ($transaction->payment_type === 'InHand') {
                $inhand += ($transaction->type === 'Credit' ? $transaction->amount : -$transaction->amount);
            } elseif ($transaction->payment_type === 'InBank') {
                $inbank += ($transaction->type === 'Credit' ? $transaction->amount : -$transaction->amount);
            }
        }
    
        return response()->json([
            'transactions' => $transactions->values(),
            'total_debit' => $total_debit,
            'total_credit' => $total_credit,
            'inhand' => $inhand,
            'inbank' => $inbank,
        ], 200);
    }

    
    
}
